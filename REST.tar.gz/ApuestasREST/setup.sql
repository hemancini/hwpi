-- Database: nlogic

DROP DATABASE nlogic;
CREATE DATABASE nlogic
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'Spanish_Chile.1252'
       LC_CTYPE = 'Spanish_Chile.1252'
       CONNECTION LIMIT = -1;
       
-- //////////////// connect to database //////////////// --       
DROP TABLE nl_user;
CREATE TABLE IF NOT EXISTS nl_user (
  user_id bigint NOT NULL,
  nick varchar(45) DEFAULT NULL,
  first_name varchar(45) DEFAULT NULL,
  last_name varchar(45) DEFAULT NULL,
  email varchar(45) DEFAULT NULL,
  phone varchar(45) DEFAULT NULL,
  PRIMARY KEY (user_id)
);

DROP SEQUENCE sequence_nl_user;
CREATE SEQUENCE sequence_nl_user
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 2
  CACHE 1;
