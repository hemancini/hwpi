package cl.nlogic.dao;

import java.util.List;

import cl.nlogic.model.Users;

public interface DataDao {

	public boolean addEntity(Users user) throws Exception;

	public Users getEntityById(long id) throws Exception;

	public List<Users> getEntityList() throws Exception;

	public boolean deleteEntity(long id) throws Exception;

}
