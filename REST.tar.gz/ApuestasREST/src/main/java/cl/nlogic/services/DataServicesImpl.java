package cl.nlogic.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import cl.nlogic.dao.DataDao;
import cl.nlogic.model.Users;

public class DataServicesImpl implements DataServices {

	@Autowired
	DataDao dataDao;
	
	@Override
	public boolean addEntity(Users user) throws Exception {
		return dataDao.addEntity(user);
	}

	@Override
	public Users getEntityById(long id) throws Exception {
		return dataDao.getEntityById(id);
	}

	@Override
	public List<Users> getEntityList() throws Exception {
		return dataDao.getEntityList();
	}

	@Override
	public boolean deleteEntity(long id) throws Exception {
		return dataDao.deleteEntity(id);
	}

}
